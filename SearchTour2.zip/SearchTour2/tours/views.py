from django.shortcuts import render
from django.views import View
from django.http import Http404, HttpResponseNotFound, HttpResponseServerError

from tours.data import title, subtitle, description, departures, tours


def custom_handler404(request, exception):
    return HttpResponseNotFound('Ошибка 404. Что-то сломалось... Извините!')


def custom_handler500(request):
    return HttpResponseServerError('Ошибка 500. Что-то сломалось... Извините!')


class MainView(View):
    def get(self, request, *args, **kwargs):
        context = {
            'title': title,
            'subtitle': subtitle,
            'description': description,
            'tours': tours.items(),
            'departures': departures.items(),
        }
        return render(request, 'index.html', context=context)


class DepartureView(View):
    def get(self, request, departure, *args, **kwargs):
        if departure not in departures.keys():
            raise Http404
        context = {
            'title': title,
            'tours': [tour for tour in tours.items() if tour[1]["departure"] == departure],
            'departureChosed': departures[departure],
            'departures': departures.items(),
        }
        context['tourslen'] = len(context['tours'])
        priceAndNights = []
        for tour in context['tours']:
            priceAndNights.append(tour[1]['price'])
        context['maxprice'] = max(priceAndNights)
        context['minprice'] = min(priceAndNights)
        for tour in context['tours']:
            priceAndNights.append(tour[1]['nights'])
        context['maxnights'] = max(priceAndNights)
        context['minnights'] = min(priceAndNights)

        # context['tourslen'] = len(context['tours'])
        # priceAndNights = [tour[1]['price'] for tour in context['tours']]
        # context['maxprice'] = max(priceAndNights)
        # context['minprice'] = min(priceAndNights)
        # priceAndNights = [tour[1]['nights'] for tour in context['tours']]
        # context['maxnights'] = max(priceAndNights)
        # context['minnights'] = min(priceAndNights)
        return render(request, 'DepartureView.html', context=context)


class TourView(View):
    def get(self, request, id, *args, **kwargs):
        if id not in tours:
            raise Http404
        context = {
            'title': title,
            'tour': tours[id],
            'departureChosed': departures[tours[id]['departure']],
            'departures': departures.items(),
        }
        return render(request, 'TourView.html', context=context)
